# RelaySkills: a thriving community for shared learning

## Why I created RelaySkills

I’m Tenzin Gyatso Joshi, a Class 9F student at Seth Anandram Jaipuria School in Lucknow. I registered for the Design Championship 2026, where I was tasked with creating SwapLabs for the competition.

After I finished the Design Championship, I realized how meaningful the SwapLabs idea was and how much this website could offer students, teachers, and learners of all kinds. Once the competition was over, I created [RelaySkills](https://relayskills.com/) as a free, full-fledged peer-to-peer learning platform and community, so people can teach one another, keep learning, and help make the Learning Mission dream come true.

## The RelaySkills community

RelaySkills is built around the idea that everyone has something they can teach and everyone has something new to learn. People can share practical skills, find a learning match, practise together, and keep growing through workshops, groups, courses, and community spaces. Its people-first approach makes learning a shared effort: search, connect, practise, and keep learning together.

Learn more at [relayskills.com](https://relayskills.com/) and explore the [RelaySkills community](https://relayskills.com/community.html).

## Relationship to SwapLabs

SwapLabs was my Design Championship project. RelaySkills came later, after the competition, when I saw the potential the idea had to help students, teachers, and learners. SwapLabs keeps its own name, branding, credits, and acknowledgements; RelaySkills has its own identity.

## Data in this repository

This public source repository does not contain real member accounts, private messages or attachments, profile uploads, credentials, or runtime databases. It contains the website source and synthetic demo fixtures only. Local clones start with a fresh data store.
